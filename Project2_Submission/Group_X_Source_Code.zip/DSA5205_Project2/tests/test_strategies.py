import numpy as np
import pandas as pd
from src.pipeline import FEATURES
from strategies import capped, pools, targets_for_date


def sample_universe():
    frame = pd.DataFrame({
        'ticker': [f'T{i:03d}' for i in range(300)],
        'mom_2_12': np.arange(300, dtype=float),
        'vol_63': np.linspace(0.1, 0.6, 300),
    })
    for feature in FEATURES:
        if feature not in frame:
            frame[feature] = 0.0
    return frame


class MomentumModel:
    def predict(self, features):
        return features.mom_2_12.to_numpy() / 100


class NegativeModel:
    def predict(self, features):
        return np.full(len(features), -1.0)


def test_s60_high_medium_low_membership_and_s30_size():
    s60, s30 = pools(sample_universe())
    assert s60.ticker.nunique() == 60
    assert s30.ticker.nunique() == 30
    assert set(s60.loc[s60.momentum_group == 'High', 'ticker']) == {f'T{i:03d}' for i in range(280, 300)}
    assert set(s60.loc[s60.momentum_group == 'Medium', 'ticker']) == {f'T{i:03d}' for i in range(140, 160)}
    assert set(s60.loc[s60.momentum_group == 'Low', 'ticker']) == {f'T{i:03d}' for i in range(20)}


def test_r1_matches_b1_and_respects_weight_cap():
    full = sample_universe()
    s60, s30 = pools(full)
    targets = targets_for_date(full, s60, s30, MomentumModel())
    assert set(targets['R1_RidgeWeighted10']) == set(targets['B1_Momentum10'])
    assert np.isclose(sum(targets['R1_RidgeWeighted10'].values()), 1.0)
    assert max(targets['R1_RidgeWeighted10'].values()) <= 0.2 + 1e-12


def test_momentum_baselines_do_not_depend_on_ridge():
    full = sample_universe()
    s60, s30 = pools(full)
    first = targets_for_date(full, s60, s30, MomentumModel())
    second = targets_for_date(full, s60, s30, NegativeModel())
    for strategy in ['B1_Momentum10', 'B2_Momentum30', 'B3_MomentumDoubleSort10']:
        assert first[strategy] == second[strategy]


def test_nonpositive_scores_fall_back_to_equal_weight_and_cap():
    tickers = [f'T{i:03d}' for i in range(10)]
    weights = capped(pd.Series(-1.0, index=tickers))
    assert np.allclose(weights, 0.1)
    weights = capped(pd.Series([100, 1, 1, 1, 1, 1, 1, 1, 1, 1], index=tickers))
    assert np.isclose(weights.sum(), 1.0)
    assert weights.max() <= 0.2 + 1e-12
    assert (weights >= 0).all()
