import numpy as np
import pandas as pd
from src.backtest import portfolio_backtest


def test_default_top10_equal_weight_and_common_benchmarks():
    rows = []
    for date in [pd.Timestamp('2022-01-31'), pd.Timestamp('2022-02-28')]:
        for i in range(30):
            rows.append({
                'decision_date': date,
                'ticker': f'T{i:02d}',
                'prediction': 1.0,
                'mom_2_12': -float(i),
                'target_forward_return': 0.01,
                'spy_return': 0.005,
                'qqq_return': 0.006,
            })
    predictions = pd.DataFrame(rows)
    returns, trades, holdings = portfolio_backtest(predictions, cost_bps=20, top_n=10)
    first_model = holdings[(holdings.strategy == 'model_top10') &
                           (holdings.decision_date == pd.Timestamp('2022-01-31'))]
    assert set(first_model.ticker) == {f'T{i:02d}' for i in range(10)}
    assert np.allclose(first_model.target_weight, 0.1)
    first_equal = holdings[(holdings.strategy == 'equal_weight_30') &
                           (holdings.decision_date == pd.Timestamp('2022-01-31'))]
    assert len(first_equal) == 30
    assert np.allclose(first_equal.target_weight, 1 / 30)
    for ticker in ['SPY', 'QQQ']:
        benchmark = returns[returns.strategy == ticker].sort_values('decision_date')
        assert np.allclose(benchmark.cost, [0.002, 0.0])
        assert np.allclose(benchmark.turnover_two_way, [1.0, 0.0])
