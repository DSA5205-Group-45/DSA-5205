import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from src.pipeline import FEATURES

ALPHAS = [0.1, 1, 10, 100, 1000, 10000]


def _choose(cell, n, group):
    if group == 'High':
        return cell.sort_values(['mom_2_12', 'ticker'], ascending=[False, True]).head(n)
    if group == 'Low':
        return cell.sort_values(['mom_2_12', 'ticker'], ascending=[True, True]).head(n)
    median = cell.mom_2_12.median()
    return cell.assign(_distance=(cell.mom_2_12 - median).abs()).sort_values(
        ['_distance', 'ticker']).head(n).drop(columns='_distance')


def pools(g):
    ranked = g.sort_values(['mom_2_12', 'ticker'], ascending=[False, True]).reset_index(drop=True)
    blocks = np.array_split(np.arange(len(ranked)), 3)
    sixties = []
    pieces = []
    for group, indices in zip(['High', 'Medium', 'Low'], blocks):
        momentum = ranked.iloc[indices].copy()
        momentum['momentum_group'] = group
        if group == 'High':
            pick = momentum.sort_values(['mom_2_12', 'ticker'], ascending=[False, True]).head(20)
        elif group == 'Medium':
            distance = (momentum.mom_2_12 - momentum.mom_2_12.median()).abs()
            pick = momentum.assign(distance=distance).sort_values(['distance', 'ticker']).head(20).drop(columns='distance')
        else:
            pick = momentum.sort_values(['mom_2_12', 'ticker'], ascending=[True, True]).head(20)
        sixties.append(pick)
        by_vol = momentum.sort_values(['vol_63', 'ticker']).reset_index(drop=True)
        for vol_group, subindices, n in zip(
                ['Low', 'Medium', 'High'], np.array_split(np.arange(len(by_vol)), 3), [3, 4, 3]):
            selected = _choose(by_vol.iloc[subindices], n, group).copy()
            selected['momentum_group'] = group
            selected['volatility_group'] = vol_group
            pieces.append(selected)
    s60 = pd.concat(sixties, ignore_index=True)
    s30 = pd.concat(pieces, ignore_index=True)
    assert s60.ticker.nunique() == 60 and s30.ticker.nunique() == 30
    return s60, s30


def capped(scores, cap=0.2):
    scores = pd.Series(scores, dtype=float).clip(lower=0)
    if scores.sum() <= 0:
        return pd.Series(1 / len(scores), index=scores.index)
    weights = scores / scores.sum()
    remaining = list(weights.index)
    result = pd.Series(0.0, index=scores.index)
    while remaining:
        proposed = scores[remaining] / scores[remaining].sum()
        available = 1 - result.sum()
        proposed = proposed * available
        over = proposed[proposed > cap + 1e-12]
        if over.empty:
            result[remaining] = proposed
            break
        for ticker in over.index:
            result[ticker] = cap
        remaining = [t for t in remaining if t not in over.index]
        if scores[remaining].sum() <= 0:
            result[remaining] = (1 - result.sum()) / len(remaining)
            break
    return result


def train_ridge(data, seed=42):
    data = data.copy()
    data['decision_date'] = pd.to_datetime(data.decision_date)
    data['label_end_date'] = pd.to_datetime(data.label_end_date)
    train = data[(data.decision_date < '2020-01-01') & (data.label_end_date <= '2020-01-01')]
    validation = data[(data.decision_date >= '2020-01-01') & (data.decision_date < '2022-01-01') &
                      (data.label_end_date <= '2022-01-01')]
    rows = []
    for alpha in ALPHAS:
        estimator = Pipeline([('scale', StandardScaler()), ('model', Ridge(alpha=alpha))])
        estimator.fit(train[FEATURES], train.target_forward_return)
        rows.append({
            'alpha': alpha,
            'train_mse': np.mean((train.target_forward_return - estimator.predict(train[FEATURES])) ** 2),
            'validation_mse': np.mean((validation.target_forward_return - estimator.predict(validation[FEATURES])) ** 2),
        })
    grid = pd.DataFrame(rows).sort_values(['validation_mse', 'alpha']).reset_index(drop=True)
    alpha = float(grid.iloc[0].alpha)
    refit = data[(data.decision_date < '2022-01-01') & (data.label_end_date <= '2022-01-01')]
    model = Pipeline([('scale', StandardScaler()), ('model', Ridge(alpha=alpha))])
    model.fit(refit[FEATURES], refit.target_forward_return)
    info = {'alpha': alpha, 'train_rows': len(train), 'validation_rows': len(validation),
            'refit_rows': len(refit), 'seed': seed}
    return model, grid, info


def targets_for_date(full, s60, s30, model):
    full = full.copy()
    s60 = s60.copy()
    s30 = s30.copy()
    full['prediction'] = model.predict(full[FEATURES])
    s60['prediction'] = model.predict(s60[FEATURES])
    s30['prediction'] = model.predict(s30[FEATURES])
    b1 = full.sort_values(['mom_2_12', 'ticker'], ascending=[False, True]).head(10)
    b2 = full.sort_values(['mom_2_12', 'ticker'], ascending=[False, True]).head(30)
    b3 = s30.sort_values(['mom_2_12', 'ticker'], ascending=[False, True]).head(10)
    r2 = s60.sort_values(['prediction', 'ticker'], ascending=[False, True]).head(10)
    r4 = s30.sort_values(['prediction', 'ticker'], ascending=[False, True]).head(10)
    r3_parts = []
    for group, n in zip(['High', 'Medium', 'Low'], [3, 4, 3]):
        group_data = s60[s60.momentum_group == group]
        r3_parts.append(group_data.sort_values(['prediction', 'ticker'], ascending=[False, True]).head(n))
    r3 = pd.concat(r3_parts)
    return {
        'B1_Momentum10': dict(zip(b1.ticker, np.repeat(0.1, 10))),
        'B2_Momentum30': dict(zip(b2.ticker, np.repeat(1 / 30, 30))),
        'B3_MomentumDoubleSort10': dict(zip(b3.ticker, np.repeat(0.1, 10))),
        'R1_RidgeWeighted10': capped(b1.set_index('ticker').prediction).to_dict(),
        'R2_RidgeFree60': dict(zip(r2.ticker, np.repeat(0.1, 10))),
        'R3_RidgeQuota343': dict(zip(r3.ticker, np.repeat(0.1, 10))),
        'R4_RidgeDoubleSort30': dict(zip(r4.ticker, np.repeat(0.1, 10))),
    }


def simulate(selections, return_lookup, cost_bps=20):
    results, trades, holdings = [], [], []
    previous = {name: ({}, {}) for name in next(iter(selections.values()))}
    for date in sorted(selections):
        for strategy, target in selections[date].items():
            prev_weights, prev_returns = previous[strategy]
            grown = {t: w * (1 + prev_returns[t]) for t, w in prev_weights.items()}
            denominator = sum(grown.values())
            pre = {t: value / denominator for t, value in grown.items()} if denominator > 0 else {}
            turnover = sum(abs(target.get(t, 0) - pre.get(t, 0)) for t in set(pre) | set(target))
            cost = turnover * cost_bps / 10000
            realized = {t: float(return_lookup[(date, t)]) for t in target}
            gross = sum(w * realized[t] for t, w in target.items())
            results.append({'strategy': strategy, 'decision_date': date, 'gross_return': gross,
                            'turnover_two_way': turnover, 'cost': cost, 'net_return': gross - cost})
            for t in sorted(set(pre) | set(target)):
                old, new = pre.get(t, 0), target.get(t, 0)
                delta = new - old
                action = ('BUY' if old == 0 and new > 0 else 'EXIT' if new == 0 else
                          'ADD' if delta > 1e-12 else 'REDUCE' if delta < -1e-12 else 'HOLD')
                trades.append({'strategy': strategy, 'decision_date': date, 'ticker': t,
                               'pretrade_weight': old, 'target_weight': new, 'delta_weight': delta,
                               'action': action, 'cost_contribution': abs(delta) * cost_bps / 10000})
            for t, w in target.items():
                holdings.append({'strategy': strategy, 'decision_date': date, 'ticker': t,
                                 'target_weight': w, 'stock_period_return': realized[t],
                                 'gross_contribution': w * realized[t]})
            previous[strategy] = (target, realized)
    return pd.DataFrame(results), pd.DataFrame(trades), pd.DataFrame(holdings)


def performance(returns, frequency='monthly'):
    annual = {'monthly': 12, 'quarterly': 4, 'semiannual': 2}[frequency]
    rows = []
    for name, g in returns.groupby('strategy'):
        g = g.sort_values('decision_date')
        r = g.net_return.astype(float)
        wealth = (1 + r).cumprod()
        rows.append({'strategy': name, 'periods': len(r),
                     'annualized_return': float(wealth.iloc[-1] ** (annual / len(r)) - 1),
                     'annualized_volatility': float(r.std(ddof=1) * np.sqrt(annual)),
                     'sharpe_rf0': float(r.mean() / r.std(ddof=1) * np.sqrt(annual)),
                     'max_drawdown': float((wealth / wealth.cummax() - 1).min()),
                     'avg_two_way_turnover': float(g.turnover_two_way.mean()),
                     'total_cost': float(g.cost.sum())})
    return pd.DataFrame(rows).sort_values('annualized_return', ascending=False).reset_index(drop=True)
