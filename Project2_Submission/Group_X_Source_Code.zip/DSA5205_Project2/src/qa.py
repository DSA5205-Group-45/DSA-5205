import numpy as np
import pandas as pd
from .pipeline import FEATURES


def corporate_action_checks(raw):
    events = raw.loc[(raw['dividends'].fillna(0) != 0) | (raw['stock_splits'].fillna(0) != 0),
                     ['date', 'ticker', 'dividends', 'stock_splits']].copy()
    return events.sort_values(['date', 'ticker']).reset_index(drop=True)


def audit_dataset(raw, screened, ready, audit):
    issues = []
    if raw.empty or screened.empty or ready.empty:
        issues.append('Empty raw, screened, or model-ready dataset')
    if raw.ticker.astype(str).str.startswith('SYN').any():
        issues.append('Synthetic tickers detected')
    if not {'SPY', 'QQQ'}.issubset(set(raw.ticker)):
        issues.append('SPY or QQQ is missing')
    if ready.duplicated(['decision_date', 'ticker']).any():
        issues.append('Duplicate decision-date/ticker rows')
    if not np.isfinite(ready[FEATURES + ['target_forward_return']].to_numpy(float)).all():
        issues.append('Non-finite model features or labels')
    counts = screened.groupby('decision_date').ticker.nunique()
    if (counts != 30).any():
        issues.append('A screened date does not contain exactly 30 candidates')
    if (ready.label_end_date <= ready.execution_date).any():
        issues.append('Label end date is not after execution date')
    return {
        'pass': not issues,
        'issues': issues,
        'raw_rows': len(raw),
        'screened_rows': len(screened),
        'ready_rows': len(ready),
        'decision_dates': int(screened.decision_date.nunique()),
        'selected_per_date': {str(k): int(v) for k, v in counts.value_counts().items()},
    }
