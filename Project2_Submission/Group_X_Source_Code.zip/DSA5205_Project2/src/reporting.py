import matplotlib.pyplot as plt
import pandas as pd


def make_reports(predictions, frequency, out_dir):
    out_dir.mkdir(parents=True, exist_ok=True)
    monthly = predictions.groupby('decision_date').apply(
        lambda g: pd.Series({
            'prediction_mse': ((g.target_forward_return - g.prediction) ** 2).mean(),
            'rank_ic': g.prediction.corr(g.target_forward_return, method='spearman'),
        }), include_groups=False,
    )
    monthly.to_csv(out_dir / 'prediction_by_period.csv')
    returns_path = out_dir / 'portfolio_returns.csv'
    if returns_path.exists():
        returns = pd.read_csv(returns_path, parse_dates=['decision_date'])
        wide = returns.pivot(index='decision_date', columns='strategy', values='net_return').sort_index()
        fig, ax = plt.subplots(figsize=(10, 5))
        (1 + wide).cumprod().plot(ax=ax)
        ax.set_title(f'Out-of-sample cumulative wealth ({frequency}, net of costs)')
        ax.set_ylabel('Growth of $1')
        fig.tight_layout()
        fig.savefig(out_dir / 'cumulative_wealth.png', dpi=160)
        plt.close(fig)
