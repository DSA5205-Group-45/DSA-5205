from pathlib import Path
import matplotlib.pyplot as plt


def visualize(screened, audit, out_dir):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(10, 4))
    if not audit.empty:
        plot_data = audit.set_index('decision_date')[['eligible_top300', 'selected']]
        plot_data.plot(ax=ax)
        ax.set_ylabel('Number of stocks')
        ax.set_xlabel('Decision date')
        ax.set_title('Screening coverage and selected candidates')
    fig.tight_layout()
    fig.savefig(out_dir / 'screening_coverage.png', dpi=160)
    plt.close(fig)
