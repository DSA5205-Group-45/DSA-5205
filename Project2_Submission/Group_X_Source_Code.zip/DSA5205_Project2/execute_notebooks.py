import argparse
from pathlib import Path
import nbformat
from nbclient import NotebookClient

parser = argparse.ArgumentParser()
parser.add_argument('--notebook', choices=['all', 'data', 'models'], default='all')
args = parser.parse_args()
root = Path(__file__).resolve().parent
paths = {
    'data': root / 'notebooks' / '01_data_pipeline.ipynb',
    'models': root / 'notebooks' / '03_model_comparison_and_ridge_strategies.ipynb',
}
selected = list(paths) if args.notebook == 'all' else [args.notebook]
for name in selected:
    path = paths[name]
    notebook = nbformat.read(path, as_version=4)
    NotebookClient(notebook, timeout=3600, kernel_name='python3',
                   resources={'metadata': {'path': str(root)}}).execute()
    nbformat.write(notebook, path)
    print('Executed:', path.relative_to(root))
